pub use core::slice::memchr::{memchr, memrchr};
