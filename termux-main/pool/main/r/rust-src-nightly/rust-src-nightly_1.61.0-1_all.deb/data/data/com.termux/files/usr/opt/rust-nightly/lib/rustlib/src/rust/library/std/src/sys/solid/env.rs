pub mod os {
    pub const FAMILY: &str = "itron";
    pub const OS: &str = "solid";
    pub const DLL_PREFIX: &str = "";
    pub const DLL_SUFFIX: &str = ".so";
    pub const DLL_EXTENSION: &str = "so";
    pub const EXE_SUFFIX: &str = "";
    pub const EXE_EXTENSION: &str = "";
}
