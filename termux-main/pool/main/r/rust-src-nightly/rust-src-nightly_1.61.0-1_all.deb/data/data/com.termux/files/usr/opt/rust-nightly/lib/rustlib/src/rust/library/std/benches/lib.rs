#![feature(test)]

extern crate test;

mod hash;
