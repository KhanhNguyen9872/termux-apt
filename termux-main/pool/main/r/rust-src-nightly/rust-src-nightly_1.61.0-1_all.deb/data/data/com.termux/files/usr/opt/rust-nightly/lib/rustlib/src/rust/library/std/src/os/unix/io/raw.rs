//! Unix-specific extensions to general I/O primitives.

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use crate::os::fd::raw::*;
