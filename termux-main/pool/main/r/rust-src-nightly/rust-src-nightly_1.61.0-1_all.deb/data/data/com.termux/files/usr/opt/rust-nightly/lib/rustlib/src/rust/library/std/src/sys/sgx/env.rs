pub mod os {
    pub const FAMILY: &str = "";
    pub const OS: &str = "";
    pub const DLL_PREFIX: &str = "";
    pub const DLL_SUFFIX: &str = ".sgxs";
    pub const DLL_EXTENSION: &str = "sgxs";
    pub const EXE_SUFFIX: &str = ".sgxs";
    pub const EXE_EXTENSION: &str = "sgxs";
}
