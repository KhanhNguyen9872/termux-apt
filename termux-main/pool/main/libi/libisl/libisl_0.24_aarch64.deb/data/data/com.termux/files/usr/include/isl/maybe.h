#ifndef ISL_MAYBE_H
#define ISL_MAYBE_H

#define ISL_xMAYBE(TYPE)	isl_maybe_ ## TYPE
#define ISL_MAYBE(TYPE)		ISL_xMAYBE(TYPE)

#endif
