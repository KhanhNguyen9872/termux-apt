//===----------------------------------------------------------------------===//
//                         DuckDB
//
// duckdb/common/string.hpp
//
//
//===----------------------------------------------------------------------===//

#pragma once

#include <string>
#include <sstream>

namespace duckdb {
using std::string;
}
