//===----------------------------------------------------------------------===//
//                         DuckDB
//
// duckdb/common/pair.hpp
//
//
//===----------------------------------------------------------------------===//

#pragma once

#include <utility>

namespace duckdb {
using std::make_pair;
using std::pair;
} // namespace duckdb
