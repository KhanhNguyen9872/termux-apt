//===----------------------------------------------------------------------===//
//                         DuckDB
//
// duckdb/common/bitset.hpp
//
//
//===----------------------------------------------------------------------===//

#pragma once

#include <bitset>

namespace duckdb {
using std::bitset;
}
