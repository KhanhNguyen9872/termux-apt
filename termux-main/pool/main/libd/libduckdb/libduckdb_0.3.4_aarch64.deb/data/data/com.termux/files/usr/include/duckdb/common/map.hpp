//===----------------------------------------------------------------------===//
//                         DuckDB
//
// duckdb/common/map.hpp
//
//
//===----------------------------------------------------------------------===//

#pragma once

#include <map>

namespace duckdb {
using std::map;
using std::multimap;
} // namespace duckdb
