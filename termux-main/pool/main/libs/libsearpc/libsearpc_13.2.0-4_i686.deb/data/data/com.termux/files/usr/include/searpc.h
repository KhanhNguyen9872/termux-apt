/* -*- Mode: C; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */

#ifndef SEARPC_H
#define SEARPC_H

#include <searpc-client.h>
#include <searpc-server.h>
#include <searpc-utils.h>

#endif
