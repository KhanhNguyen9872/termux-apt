#!/data/data/com.termux/files/usr/bin/sh
sed -n '/BEGIN/,$p' | keybase pgp decrypt
