/*  Part of SWI-Prolog

    This example code is in the public domain
*/

% See test.cpp for compiling the foreign code to a plugin.

:- use_foreign_library(test).

a(1).
a(2).
%a(a).
a(4).
