
my_ext = {
    whoami: "GPAC-GUI-Extension",
    name: "About",
    icon: "info.svg",
    author: "JeanLF",
    description: "About GPAC",
    url: "http://gpac.io/",
    execjs: ["info.js"],
    autostart: false,
    config_id: "ABOUT",
    requires_gl: false,
    version_major: 1,
    version_minor: 0
};
