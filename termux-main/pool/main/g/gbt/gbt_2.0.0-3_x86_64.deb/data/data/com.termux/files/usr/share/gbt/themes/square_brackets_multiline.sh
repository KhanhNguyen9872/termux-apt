export GBT_SEPARATOR="]─["

export GBT_CAR_BG="default"

export GBT_CAR_DIR_FG="cyan"

export GBT_CAR_GIT_FG="default"
export GBT_CAR_GIT_STATUS_DIRTY_FG="red"
export GBT_CAR_GIT_STATUS_CLEAN_FG="green"

export GBT_CAR_EXECTIME_FG="green"

export GBT_CAR_STATUS_ERROR_FG="red"
export GBT_CAR_STATUS_ERROR_BG="default"
export GBT_CAR_STATUS_OK_FG="green"
export GBT_CAR_STATUS_OK_BG="default"

export GBT_CAR_HOSTNAME_USER_FG="yellow"
export GBT_CAR_HOSTNAME_HOST_FG="light_green"

export GBT_CAR_PYVIRTENV_NAME_FG="default"

export GBT_BEGINNING_TEXT="┌─["

export GBT_CAR_SIGN_FORMAT="└──╼ "
export GBT_CAR_SIGN_SEP="]"
export GBT_CAR_SIGN_WRAP=1
