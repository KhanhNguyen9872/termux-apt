/**
 * @file pandadx9.h
 * @author masad
 * @date 2004-01-15
 */

#ifndef PANDADX9_H
#define PANDADX9_H

#include "pandabase.h"

EXPCL_PANDADX void init_libpandadx9();
extern "C" EXPCL_PANDADX int get_pipe_type_pandadx9();

#endif
