/**
 * @file pandaphysics.h
 * @author drose
 * @date 2001-01-02
 */

#ifndef PANDAPHYSICS_H
#define PANDAPHYSICS_H

#include "pandabase.h"

EXPCL_PANDAPHYSICS void init_libpandaphysics();

#endif
