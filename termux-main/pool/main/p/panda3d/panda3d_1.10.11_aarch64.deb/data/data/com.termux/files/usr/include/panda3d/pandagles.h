/**
 * @file pandagles.h
 * @author rdb
 * @date 2009-06-08
 */

#ifndef PANDAGLES_H
#define PANDAGLES_H

#include "pandabase.h"

EXPCL_PANDAGLES void init_libpandagles();
extern "C" EXPCL_PANDAGLES int get_pipe_type_pandagles();

#endif
