/* prc_parameters.h.  Generated automatically by makepanda.py */
#define DEFAULT_PRC_DIR "<auto>etc"
#define PRC_DCONFIG_TRUST_LEVEL 0
#define PRC_DIR_ENVVARS "PANDA_PRC_DIR"
#define PRC_ENCRYPTED_PATTERNS "*.prc.pe"
#define PRC_ENCRYPTION_KEY ""
#define PRC_EXECUTABLE_ARGS_ENVVAR "PANDA_PRC_XARGS"
#define PRC_EXECUTABLE_PATTERNS ""
#define PRC_INC_TRUST_LEVEL 0
#define PRC_PATH2_ENVVARS ""
#define PRC_PATH_ENVVARS "PANDA_PRC_PATH"
#define PRC_PATTERNS "*.prc"
#define PRC_PUBLIC_KEYS_FILENAME ""
#undef PRC_RESPECT_TRUST_LEVEL
