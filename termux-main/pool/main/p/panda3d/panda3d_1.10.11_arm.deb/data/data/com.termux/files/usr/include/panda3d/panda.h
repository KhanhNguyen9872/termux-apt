/**
 * @file panda.h
 * @author drose
 * @date 2001-01-02
 */

#ifndef PANDA_H
#define PANDA_H

#include "pandabase.h"

EXPCL_LIBPANDA void init_libpanda();

#endif
