-- Copyright 2006-2017 Mitchell mitchell.att.foicica.com. See LICENSE.
-- Container LPeg lexer.
-- This is SciTE's plain text lexer.

local M = {_NAME = 'container'}

return M
