<?php
// Title
$title = "Tenki";
// Theme (light dark, sepia)
$theme = "dark";
// Number of entries to display
$inum = 7;
//Enable password protection
$protect = true;
// Password
$passwd = 'monkey';
// Timezone
$tz = 'Europe/Berlin';
// Footer
$footer = "Read the <a href='https://dmpop.gumroad.com/l/php-right-away'>PHP Right Away</a> book";
// Openweathermap API key
$api_key = "ee3752672ae1423b9bb92919e2b51e97";
?>
