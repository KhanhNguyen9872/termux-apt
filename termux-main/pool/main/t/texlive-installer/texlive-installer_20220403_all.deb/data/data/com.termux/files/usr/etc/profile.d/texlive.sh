export PATH=$PATH:/data/data/com.termux/files/usr/bin/texlive
