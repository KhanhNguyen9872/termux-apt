export TMUX_TMPDIR=/data/data/com.termux/files/usr/var/run
