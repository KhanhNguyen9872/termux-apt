name    = 'LÖVR'
words   = {'lovr%.%w+'}
configs = {
    {
        key    = 'Lua.runtime.version',
        action = 'set',
        value  = 'LuaJIT',
    },
}
