---@meta
---@class debug
local debug = {}

---初始化 debug 
---@param skynet table
---@param export table
function debug.init(skynet, export)

end
---注册一个 debug 指令函数
---@param name string
---@param fn fun()
function debug.reg_debugcmd(name, fn)

end
return debug
