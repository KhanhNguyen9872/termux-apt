---@meta

---@class ccs.RotationSkewFrame :ccs.SkewFrame
local RotationSkewFrame={ }
ccs.RotationSkewFrame=RotationSkewFrame




---* 
---@return self
function RotationSkewFrame:create () end
---* 
---@return ccs.Frame
function RotationSkewFrame:clone () end
---* 
---@return self
function RotationSkewFrame:RotationSkewFrame () end