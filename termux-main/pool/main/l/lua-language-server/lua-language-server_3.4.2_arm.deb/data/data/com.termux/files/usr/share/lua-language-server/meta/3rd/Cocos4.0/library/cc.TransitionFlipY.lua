---@meta

---@class cc.TransitionFlipY :cc.TransitionSceneOriented
local TransitionFlipY={ }
cc.TransitionFlipY=TransitionFlipY




---@overload fun(float:float,cc.Scene:cc.Scene):self
---@overload fun(float:float,cc.Scene:cc.Scene,int:int):self
---@param t float
---@param s cc.Scene
---@param o int
---@return self
function TransitionFlipY:create (t,s,o) end
---* 
---@return self
function TransitionFlipY:TransitionFlipY () end