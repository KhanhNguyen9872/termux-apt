includes(path.join(os.scriptdir(), "../gcc/xmake.lua"))

toolchain_gcc("4.9")
