import Foundation

print("hello world!")
