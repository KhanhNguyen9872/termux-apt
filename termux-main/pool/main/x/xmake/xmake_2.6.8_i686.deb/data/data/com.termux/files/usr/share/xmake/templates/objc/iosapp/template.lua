template("xcode.iosapp")
    add_configfiles("xmake.lua")
