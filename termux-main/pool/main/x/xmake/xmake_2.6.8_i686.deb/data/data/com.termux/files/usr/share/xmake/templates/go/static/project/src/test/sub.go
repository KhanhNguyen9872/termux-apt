package module

func Sub(a int, b int) int {
    return a - b;
}

