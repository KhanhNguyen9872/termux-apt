extern crate foo;

fn main() {
    println!("hello xmake!");
    println!("add: {}", foo::add(1, 1));
}
