fn main() {
    println!("hello xmake!");
}
