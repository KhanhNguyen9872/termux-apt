includes(path.join(os.scriptdir(), "../clang/xmake.lua"))

toolchain_clang("12")
