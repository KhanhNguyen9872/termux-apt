#
# Configuration file for using the XML library in GNOME applications
#
prefix="/data/data/com.termux/files/usr"
exec_prefix="${prefix}"
libdir="/data/data/com.termux/files/usr/lib"
includedir="${prefix}/include"

XMLSEC_LIBDIR="/data/data/com.termux/files/usr/lib"
XMLSEC_INCLUDEDIR=" -D__XMLSEC_FUNCTION__=__func__ -DXMLSEC_NO_SIZE_T -DXMLSEC_NO_GOST=1 -DXMLSEC_NO_GOST2012=1 -DXMLSEC_NO_CRYPTO_DYNAMIC_LOADING=1 -I${prefix}/include/xmlsec1   -I/data/data/com.termux/files/usr/include/libxml2 -I/data/data/com.termux/files/usr/include -I/data/data/com.termux/files/usr/include/libxml2 -I/data/data/com.termux/files/usr/include -DXMLSEC_CRYPTO_OPENSSL=1"
XMLSEC_LIBS="-L/data/data/com.termux/files/usr/lib -lxmlsec1-openssl -lxmlsec1   -L/data/data/com.termux/files/usr/lib -lxml2 -L/data/data/com.termux/files/usr/lib -lxslt -lxml2 -L/data/data/com.termux/files/usr/lib -lssl -lcrypto"
MODULE_VERSION="xmlsec-1.2.31-openssl"

