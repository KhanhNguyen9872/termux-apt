# frozen_string_literal: true
module Asciidoctor
  VERSION = '2.0.17'
end
